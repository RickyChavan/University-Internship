
import json

# Create a much simpler, cleaner workflow structure
workflow = {
    "name": "QS Ranking Lookup",
    "nodes": [
        {
            "parameters": {},
            "id": "node1",
            "name": "Manual Trigger",
            "type": "n8n-nodes-base.manualTrigger",
            "typeVersion": 1,
            "position": [240, 300]
        },
        {
            "parameters": {
                "filePath": "/data/scopus_finlit_with_country.csv"
            },
            "id": "node2",
            "name": "Read CSV",
            "type": "n8n-nodes-base.readBinaryFile",
            "typeVersion": 1,
            "position": [440, 300]
        },
        {
            "parameters": {
                "operation": "toJson",
                "options": {
                    "headerRow": True
                }
            },
            "id": "node3",
            "name": "Parse CSV",
            "type": "n8n-nodes-base.convertToFile",
            "typeVersion": 1.1,
            "position": [640, 300]
        },
        {
            "parameters": {
                "batchSize": 10,
                "options": {}
            },
            "id": "node4",
            "name": "Split In Batches",
            "type": "n8n-nodes-base.splitInBatches",
            "typeVersion": 3,
            "position": [840, 300]
        },
        {
            "parameters": {
                "modelId": "gpt-3.5-turbo",
                "messages": {
                    "values": [
                        {
                            "content": "={{ \"Return ONLY the numeric QS World University Ranking 2026 for this institution: \" + $json.Affiliations + \". Reply with just the number or NR if not ranked.\" }}"
                        }
                    ]
                },
                "options": {
                    "temperature": 0.3,
                    "maxTokens": 10
                }
            },
            "id": "node5",
            "name": "OpenAI Query",
            "type": "n8n-nodes-base.openAi",
            "typeVersion": 1.3,
            "position": [1040, 300]
        },
        {
            "parameters": {
                "assignments": {
                    "assignments": [
                        {
                            "id": "ranking",
                            "name": "qs rank 2026",
                            "value": "={{ $json.message.content }}",
                            "type": "string"
                        }
                    ]
                },
                "options": {}
            },
            "id": "node6",
            "name": "Add Rank",
            "type": "n8n-nodes-base.set",
            "typeVersion": 3.3,
            "position": [1240, 300]
        }
    ],
    "connections": {
        "Manual Trigger": {
            "main": [
                [
                    {
                        "node": "Read CSV",
                        "type": "main",
                        "index": 0
                    }
                ]
            ]
        },
        "Read CSV": {
            "main": [
                [
                    {
                        "node": "Parse CSV",
                        "type": "main",
                        "index": 0
                    }
                ]
            ]
        },
        "Parse CSV": {
            "main": [
                [
                    {
                        "node": "Split In Batches",
                        "type": "main",
                        "index": 0
                    }
                ]
            ]
        },
        "Split In Batches": {
            "main": [
                [
                    {
                        "node": "OpenAI Query",
                        "type": "main",
                        "index": 0
                    }
                ]
            ]
        },
        "OpenAI Query": {
            "main": [
                [
                    {
                        "node": "Add Rank",
                        "type": "main",
                        "index": 0
                    }
                ]
            ]
        },
        "Add Rank": {
            "main": [
                [
                    {
                        "node": "Split In Batches",
                        "type": "main",
                        "index": 0
                    }
                ]
            ]
        }
    },
    "pinData": {},
    "settings": {
        "executionOrder": "v1"
    },
    "staticData": None,
    "tags": [],
    "triggerCount": 0,
    "updatedAt": "2026-01-17T12:36:00.000Z",
    "versionId": "1"
}

# Save with proper JSON formatting
with open('qs_ranking_workflow_simple.json', 'w', encoding='utf-8') as f:
    json.dump(workflow, f, indent=2)

print("✅ Simplified workflow created: qs_ranking_workflow_simple.json")
print("\n📝 This is a MINIMAL working version that:")
print("  1. Reads your CSV file")
print("  2. Parses it row by row")
print("  3. Processes in batches of 10")
print("  4. Queries OpenAI for QS ranking")
print("  5. Adds 'qs rank 2026' column to each row")
print("\n⚠️  Note: You'll need to add output/export node manually")
print("   (This simplifies import to avoid errors)")
