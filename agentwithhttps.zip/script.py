
import json

# Create a workflow using HTTP Request instead of OpenAI node
workflow = {
    "name": "QS Ranking with HTTP Request",
    "nodes": [
        {
            "parameters": {},
            "id": "manual-trigger",
            "name": "Manual Trigger",
            "type": "n8n-nodes-base.manualTrigger",
            "typeVersion": 1,
            "position": [240, 300]
        },
        {
            "parameters": {
                "filePath": "/home/node/.n8n-files/scopus_finlit_with_country.csv"
            },
            "id": "read-csv",
            "name": "Read CSV",
            "type": "n8n-nodes-base.readBinaryFile",
            "typeVersion": 1,
            "position": [440, 300]
        },
        {
            "parameters": {
                "operation": "toJson",
                "options": {
                    "headerRow": True
                }
            },
            "id": "parse-csv",
            "name": "Parse CSV",
            "type": "n8n-nodes-base.convertToFile",
            "typeVersion": 1.1,
            "position": [640, 300]
        },
        {
            "parameters": {
                "batchSize": 10,
                "options": {}
            },
            "id": "split-batches",
            "name": "Split In Batches",
            "type": "n8n-nodes-base.splitInBatches",
            "typeVersion": 3,
            "position": [840, 300]
        },
        {
            "parameters": {
                "method": "POST",
                "url": "https://api.openai.com/v1/chat/completions",
                "authentication": "genericCredentialType",
                "genericAuthType": "httpHeaderAuth",
                "sendHeaders": True,
                "headerParameters": {
                    "parameters": [
                        {
                            "name": "Authorization",
                            "value": "=Bearer {{ $credentials.openaiApi.apiKey }}"
                        },
                        {
                            "name": "Content-Type",
                            "value": "application/json"
                        }
                    ]
                },
                "sendBody": True,
                "bodyParameters": {
                    "parameters": []
                },
                "specifyBody": "json",
                "jsonBody": "={{ \n  JSON.stringify({\n    \"model\": \"gpt-3.5-turbo\",\n    \"messages\": [\n      {\n        \"role\": \"user\",\n        \"content\": \"Return ONLY the numeric QS World University Ranking 2026 for this institution: \" + $json.Affiliations + \". Reply with just the number or NR if not ranked. No other text.\"\n      }\n    ],\n    \"temperature\": 0.3,\n    \"max_tokens\": 10\n  })\n}}",
                "options": {}
            },
            "id": "openai-http",
            "name": "Query OpenAI API",
            "type": "n8n-nodes-base.httpRequest",
            "typeVersion": 4.2,
            "position": [1040, 300]
        },
        {
            "parameters": {
                "assignments": {
                    "assignments": [
                        {
                            "id": "qs-rank",
                            "name": "qs rank 2026",
                            "value": "={{ $json.choices[0].message.content.trim() }}",
                            "type": "string"
                        }
                    ]
                },
                "options": {}
            },
            "id": "add-rank",
            "name": "Add QS Rank",
            "type": "n8n-nodes-base.set",
            "typeVersion": 3.3,
            "position": [1240, 300]
        }
    ],
    "connections": {
        "Manual Trigger": {
            "main": [
                [
                    {
                        "node": "Read CSV",
                        "type": "main",
                        "index": 0
                    }
                ]
            ]
        },
        "Read CSV": {
            "main": [
                [
                    {
                        "node": "Parse CSV",
                        "type": "main",
                        "index": 0
                    }
                ]
            ]
        },
        "Parse CSV": {
            "main": [
                [
                    {
                        "node": "Split In Batches",
                        "type": "main",
                        "index": 0
                    }
                ]
            ]
        },
        "Split In Batches": {
            "main": [
                [
                    {
                        "node": "Query OpenAI API",
                        "type": "main",
                        "index": 0
                    }
                ]
            ]
        },
        "Query OpenAI API": {
            "main": [
                [
                    {
                        "node": "Add QS Rank",
                        "type": "main",
                        "index": 0
                    }
                ]
            ]
        },
        "Add QS Rank": {
            "main": [
                [
                    {
                        "node": "Split In Batches",
                        "type": "main",
                        "index": 0
                    }
                ]
            ]
        }
    },
    "pinData": {},
    "settings": {
        "executionOrder": "v1"
    },
    "staticData": None,
    "tags": [],
    "triggerCount": 0,
    "updatedAt": "2026-01-17T13:05:00.000Z",
    "versionId": "1"
}

with open('qs_ranking_http_request.json', 'w', encoding='utf-8') as f:
    json.dump(workflow, f, indent=2)

print("✅ Created new workflow: qs_ranking_http_request.json")
print("\nThis workflow uses HTTP Request instead of OpenAI node")
print("(No community node installation needed!)")
