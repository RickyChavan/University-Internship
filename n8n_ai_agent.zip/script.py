
import json

# Create n8n workflow JSON
workflow = {
    "name": "QS Ranking Lookup for Affiliations",
    "nodes": [
        {
            "parameters": {
                "filePath": "/data/scopus_finlit_with_country.csv",
                "options": {}
            },
            "id": "1",
            "name": "Read CSV File",
            "type": "n8n-nodes-base.readBinaryFile",
            "typeVersion": 1,
            "position": [250, 300]
        },
        {
            "parameters": {
                "operation": "toText",
                "options": {}
            },
            "id": "2",
            "name": "Convert to Text",
            "type": "n8n-nodes-base.convertToFile",
            "typeVersion": 1,
            "position": [450, 300]
        },
        {
            "parameters": {
                "assignments": {
                    "assignments": [
                        {
                            "id": "csv_data",
                            "name": "csv_data",
                            "value": "={{ $json.data }}",
                            "type": "string"
                        }
                    ]
                },
                "options": {}
            },
            "id": "3",
            "name": "Extract CSV Data",
            "type": "n8n-nodes-base.set",
            "typeVersion": 3.2,
            "position": [650, 300]
        },
        {
            "parameters": {
                "jsCode": "// Parse CSV and prepare data for processing\nconst csvData = $input.first().json.csv_data;\nconst lines = csvData.split('\\n');\nconst headers = lines[0].split(',');\n\n// Find the affiliation column index\nconst affiliationIndex = headers.indexOf('Affiliations');\n\nconst items = [];\nfor (let i = 1; i < lines.length; i++) {\n  if (lines[i].trim() === '') continue;\n  \n  const values = lines[i].split(',');\n  const rowData = {};\n  \n  headers.forEach((header, index) => {\n    rowData[header] = values[index] || '';\n  });\n  \n  items.push({\n    json: {\n      ...rowData,\n      rowIndex: i\n    }\n  });\n}\n\nreturn items;"
            },
            "id": "4",
            "name": "Parse CSV",
            "type": "n8n-nodes-base.code",
            "typeVersion": 2,
            "position": [850, 300]
        },
        {
            "parameters": {
                "batchSize": 10,
                "options": {}
            },
            "id": "5",
            "name": "Split In Batches",
            "type": "n8n-nodes-base.splitInBatches",
            "typeVersion": 3,
            "position": [1050, 300]
        },
        {
            "parameters": {
                "resource": "text",
                "operation": "message",
                "model": "gpt-4-turbo-preview",
                "messages": {
                    "values": [
                        {
                            "role": "system",
                            "content": "You are a helpful assistant that looks up QS World University Rankings 2026. When given a university or institution name, respond with ONLY the numeric ranking (e.g., '25', '150', 'NR' for not ranked). Do not include any additional text, explanations, or punctuation."
                        },
                        {
                            "role": "user",
                            "content": "=What is the QS World University Ranking 2026 for {{ $json.Affiliations }}? Reply with only the number or 'NR' if not ranked."
                        }
                    ]
                },
                "options": {
                    "temperature": 0.3,
                    "maxTokens": 10
                }
            },
            "id": "6",
            "name": "OpenAI - Get QS Ranking",
            "type": "n8n-nodes-base.openAi",
            "typeVersion": 1.3,
            "position": [1250, 300],
            "credentials": {
                "openAiApi": {
                    "id": "YOUR_OPENAI_CREDENTIAL_ID",
                    "name": "OpenAI account"
                }
            }
        },
        {
            "parameters": {
                "jsCode": "// Extract the ranking from OpenAI response\nconst response = $input.first().json.message?.content || 'NR';\nconst ranking = response.trim();\n\n// Add the ranking to the existing data\nconst allData = $input.first().json;\n\nreturn [{\n  json: {\n    ...allData,\n    'qs rank 2026': ranking\n  }\n}];"
            },
            "id": "7",
            "name": "Add Ranking to Row",
            "type": "n8n-nodes-base.code",
            "typeVersion": 2,
            "position": [1450, 300]
        },
        {
            "parameters": {
                "assignments": {
                    "assignments": [
                        {
                            "id": "accumulated_data",
                            "name": "accumulated_data",
                            "value": "={{ $json }}",
                            "type": "object"
                        }
                    ]
                },
                "options": {}
            },
            "id": "8",
            "name": "Collect Results",
            "type": "n8n-nodes-base.set",
            "typeVersion": 3.2,
            "position": [1650, 300]
        },
        {
            "parameters": {
                "jsCode": "// Aggregate all processed rows\nconst allItems = $input.all();\n\n// Get all unique column names\nconst headers = new Set();\nallItems.forEach(item => {\n  Object.keys(item.json).forEach(key => {\n    if (key !== 'rowIndex') {\n      headers.add(key);\n    }\n  });\n});\n\n// Ensure 'qs rank 2026' is included\nconst columnHeaders = Array.from(headers);\n\n// Create CSV output\nlet csv = columnHeaders.join(',') + '\\n';\n\nallItems.forEach(item => {\n  const row = columnHeaders.map(header => {\n    const value = item.json[header] || '';\n    // Escape commas and quotes in CSV\n    if (typeof value === 'string' && (value.includes(',') || value.includes('\"'))) {\n      return '\"' + value.replace(/\"/g, '\"\"') + '\"';\n    }\n    return value;\n  }).join(',');\n  csv += row + '\\n';\n});\n\nreturn [{\n  json: {\n    csvOutput: csv\n  }\n}];"
            },
            "id": "9",
            "name": "Create Final CSV",
            "type": "n8n-nodes-base.code",
            "typeVersion": 2,
            "position": [1850, 300]
        },
        {
            "parameters": {
                "fileName": "scopus_finlit_with_qs_ranking.csv",
                "dataPropertyName": "csvOutput",
                "options": {}
            },
            "id": "10",
            "name": "Write CSV File",
            "type": "n8n-nodes-base.writeBinaryFile",
            "typeVersion": 1,
            "position": [2050, 300]
        }
    ],
    "connections": {
        "Read CSV File": {
            "main": [[{"node": "Convert to Text", "type": "main", "index": 0}]]
        },
        "Convert to Text": {
            "main": [[{"node": "Extract CSV Data", "type": "main", "index": 0}]]
        },
        "Extract CSV Data": {
            "main": [[{"node": "Parse CSV", "type": "main", "index": 0}]]
        },
        "Parse CSV": {
            "main": [[{"node": "Split In Batches", "type": "main", "index": 0}]]
        },
        "Split In Batches": {
            "main": [[{"node": "OpenAI - Get QS Ranking", "type": "main", "index": 0}]]
        },
        "OpenAI - Get QS Ranking": {
            "main": [[{"node": "Add Ranking to Row", "type": "main", "index": 0}]]
        },
        "Add Ranking to Row": {
            "main": [[{"node": "Collect Results", "type": "main", "index": 0}]]
        },
        "Collect Results": {
            "main": [[{"node": "Split In Batches", "type": "main", "index": 0}]]
        },
        "Split In Batches": {
            "main": [[None], [{"node": "Create Final CSV", "type": "main", "index": 0}]]
        },
        "Create Final CSV": {
            "main": [[{"node": "Write CSV File", "type": "main", "index": 0}]]
        }
    },
    "pinData": {},
    "settings": {
        "executionOrder": "v1"
    },
    "staticData": None,
    "tags": [],
    "triggerCount": 0,
    "updatedAt": "2026-01-17T12:26:00.000Z",
    "versionId": "1"
}

# Save to JSON file
with open('qs_ranking_workflow.json', 'w', encoding='utf-8') as f:
    json.dump(workflow, f, indent=2)

print("Workflow created: qs_ranking_workflow.json")
print("\nWorkflow includes:")
print("✓ CSV file reader")
print("✓ Data parser")
print("✓ Batch processing (10 rows at a time)")
print("✓ OpenAI API integration for QS ranking lookup")
print("✓ New column creation: 'qs rank 2026'")
print("✓ CSV output writer")
